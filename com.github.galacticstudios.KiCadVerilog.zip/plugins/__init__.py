from .kicadverilog_action import KiCadVerilogAction

KiCadVerilogAction().register() 
